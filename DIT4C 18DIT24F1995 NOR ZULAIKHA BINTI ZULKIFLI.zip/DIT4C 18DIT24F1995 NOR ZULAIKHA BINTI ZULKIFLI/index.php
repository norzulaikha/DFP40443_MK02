<?php
$nama = "NUR ZULAIKHA BINTI ZULKIFLI";
$nomatrik = "18DIT24F1995";
$kelas = "DIT4C";
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <title>Pengenalan Diri</title>
</head>
<body>
   <center>

    <h1>PENGENALAN DIRI</h1>
    <img src="ikha.png" width="200" alt="Gambar Pelajar">

    <p><strong>Nama:</strong> <?= $nama ?></p>
    <p><strong>No Matrik:</strong> <?= $nomatrik ?></p>
    <p><strong>Kelas:</strong> <?= $kelas ?></p>

    <p><strong>Kursus:</strong> DIPLOMA TEKNOLOGI MAKLUMAT</p>
    </center>
</body>
</html>
